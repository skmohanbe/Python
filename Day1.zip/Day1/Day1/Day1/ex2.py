from math import pi,sin,factorial
a=pi*5**2
print(a)
b=factorial(6)
print(b)
m=sin(pi/6)
print(m)