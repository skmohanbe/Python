import random 
for i in range(1,20+1):
    print(i,end=' .')
    randomVariable=random.randint(1,100) 
    if 10<randomVariable<60: 
        if randomVariable > 43: 
            print(f"the value {randomVariable} is huge") 
        elif randomVariable in range (35,43): 
            print("the value {} is medium".format(randomVariable)) 
        else: 
            print(f"the value {randomVariable} is small") 
    else: 
        print(f"the value {randomVariable} is out of range")