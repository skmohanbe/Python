d={'name':'Nishant','age':89,("dept",'other'):"L&D",
   'name':['suresh','Naresh','panna'],
   89767.78:"info_about_no"}
print(d)
print(id(d),type(d),len(d))

#g=d['name']
# g=d.get('name1','key not found!')
# print(g)

# for h in d: # retrun only keys 
#     print(h)

m=d.items()#d.keys()#d.values()
print(m)
print(type(m))
v=tuple(m)#list(m)
print(v)
print(type(v))
