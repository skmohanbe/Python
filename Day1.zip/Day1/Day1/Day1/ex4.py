# for i in ("Nishant","Test","How",23,90.78,{89,90},[90,67]):
#     print(i)
#     
# for i in {34,89,90}:
#     print(i)

for i in [56,89,59,46,98,56]:
    if i%2==1:
        continue
    print(i)
    
print('Done')