d={'name':'Nishant','age':89,("dept",'other'):"L&D",
   'name':['suresh','Naresh','panna'],
   89767.78:"info_about_no"}

#d=dict(key1=value1,key2=value2,-------)
#d=dict(name='Nishant',age=90,dept=89,_7868="test")
print(d)
print(id(d),type(d),len(d))