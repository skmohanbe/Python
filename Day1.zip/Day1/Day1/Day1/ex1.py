a=[1,'Hello',3.5,"Hello",[(1,2,[67,['Test',]]),89],'Hello',"Hi", "Hello"]
print(a)
print(type(a))
print(len(a),id(a))
# b=a[3][0][-1][-1][0]
# print(b)
# 
# a[3][0][-1][-1][0]="Hello"
# print(a)
# print(id(a))
#update A list in python 
# a=[45,89,]
# print(a)
# print(len(a),id(a))

#a.append(('Hello',"Test"))
#a.insert(1, (45,89,89.787))

# a.extend((56,89))
# print(a)
# print(len(a),id(a))
a=[1,'Hello',3.5,"Hello",[(1,2,[67,['Test',]]),89],'Hello',"Hi", "Hello"]
print(a)
print(type(a))
print(len(a),id(a))
#delete the element from the list
# del a[2]
#a.remove(3.5)
#remove the all values of Hello from the given list ?
#m=a.pop(3) # return the deleted value from the list
for i in a: 
    if i == "Hello":
        a.remove(i) 
print(a)
print(len(a),id(a))