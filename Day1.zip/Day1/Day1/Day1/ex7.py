d={'name':'Nishant','age':89,("dept",'other'):"L&D",
   'name':['suresh','Naresh','panna'],
   89767.78:"info_about_no"}
print(d)
print(id(d),type(d),len(d))

#d['name']="Ramu Kaka"
# d['new key']="Data To New Key"
d2={"Test":90,"Test2":91}
d.update(d2)

print(d)
print(id(d),type(d),len(d))


#del d['name']
m=d.pop('name',None)

print(m)

print(d)
print(id(d),type(d),len(d))