import re

NameAge= """
Janice is 22 and Theon is 30
Gabriel is 44 and Joye is 21 
"""
ages=re.findall(r'\d{1,3}',NameAge)
names=re.findall(r'[A-Z][a-z]*',NameAge)
print(ages)
print(names)
# convert into dict like {'name1':age1,....}