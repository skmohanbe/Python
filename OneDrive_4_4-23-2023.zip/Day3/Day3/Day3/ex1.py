seq=[1,2,3,4,5]
# m=list(map(lambda c : c**2/0.98,seq))
# print(m)
#sum of all values
res=1 #
for i in seq:
    res=res*i 
     
print(res)
from functools import reduce
f=reduce(lambda x,y :x*y , seq)
print(f)