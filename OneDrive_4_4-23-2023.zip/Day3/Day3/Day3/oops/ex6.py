class Vehicle:
    var=90
    def general_usage(self):
        print("general use: transporation")

class Car(Vehicle):
    var=78
    def __init__(self):
        print("I'm car")
        self.wheels = 4
        self.has_roof = True
    def specific_usage(self):
        print(self.var,Vehicle.var)
        self.general_usage() #call Vehicle class method inside Car Class Method
        print("specific use: commute to work, vacation with family")
        
        
c=Car()
print(c.wheels)
c.specific_usage()
c.general_usage()
print(c.var)
print(Vehicle.var)

class MotorCycle:
    def __init__(self):
        print("I'm motor cycle")
        self.wheels = 2
        self.has_roof = False

    def specific_usage(self):
        
        print("specific use: road trip, racing")
