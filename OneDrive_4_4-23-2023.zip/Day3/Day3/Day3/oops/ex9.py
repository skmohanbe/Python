
class Father:
    def __init__(self,fname):
        self.fname=fname
    def skills(self):
        print("i enjoy gardening.",self.fname)
               
class Mother:
    def __init__(self,mname):
        
        self.mname=mname
    def skills(self):
        print('i love cooking.',self.mname)
         
class Child(Mother,Father):
    def __init__(self,name,mname,fname):
        self.name=name
        Mother.__init__(self, mname)
        Father.__init__(self, fname)

        
    def skills(self):
        Father.skills(self)
        Mother.skills(self)
        print("I enjoy PUB-G",self.name)
         
c=Child("me",'ma',"pa")
c.skills()
# Father.skills(c)
# Mother.skills(c)

        
        