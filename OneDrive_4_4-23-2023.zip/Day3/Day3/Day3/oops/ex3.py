class details:
    i=0
    print("This is details class:")
    def __init__(self):
        details.i +=1
        print("This is init method",self.i)
        self.name="Harish"
       
        
obj1=details()
# print(obj1.i,obj1.name)
obj2=details()
# print(obj2.i,obj2.name)
print(obj1.i)
        