class Car:
    def __init__(self, name, type, worth):
        print( f"{name} is a {type} worth {worth}")
car1 = Car("Fer", "Red convertible", "$60000")
car2 = Car("Jump", "Blue Van", "$10000")
