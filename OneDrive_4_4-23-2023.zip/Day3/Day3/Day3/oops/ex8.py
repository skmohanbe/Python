#Multilevel Inheritance
class Father:
    def __init__(self,fname):
        self.fname=fname
    def skills(self):
        print("i enjoy gardening.",self.fname)
               
class Mother(Father):
    def __init__(self,mname,fname):
        super().__init__(fname)
        self.mname=mname
    def skills(self):
        print('i love cooking.',self.mname)
         
class Child(Mother):
    def __init__(self,name,mname,fname):
        self.name=name
        super().__init__(mname, fname)
    def skills(self):
        Father.skills(self)
        Mother.skills(self)
        print("I enjoy PUB-G",self.name)
         
c=Child("me",'ma',"pa")
c.skills()
# Father.skills(c)
# Mother.skills(c)

        
        