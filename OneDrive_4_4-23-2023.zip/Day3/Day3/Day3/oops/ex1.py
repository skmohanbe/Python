class DemoClass:
    print("This is DemoClass.")
    var=10
    
    
obj1=DemoClass()
print(obj1)
print(obj1.var)
print(DemoClass.var)
obj1.var =90
print(DemoClass.var)
print(obj1.var)