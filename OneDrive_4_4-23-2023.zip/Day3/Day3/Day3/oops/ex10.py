class Father:
    def __init__(self,fname,age,dept):
        self.fname=fname #public
        self._age=age #protected
        self.__dept=dept #private
    def skills(self):
        print("i enjoy gardening.",self.__dept)
        
obj=Father('Nishant',67,"L&d")
print(obj.fname)
obj.fname='Test'
print(obj.fname)
print(obj._age)
obj._age=90
print(obj._age)
# print(obj.__dept)
obj.skills()