class DemoClass:
    var=10
    print("This is demo class")
    def call(self,age=78,dept='L&D'): 
        print('this is call method.')
        dept1="SocGen "+dept #local
        self.dept1=dept1#makeitglobalInOops
        return dept1,age
    def out(self):
        return self.var,self.dept1
        
        
obj1 =DemoClass()
print(obj1)
print(obj1.var)
v=obj1.call(dept="IT",age=45)
print(v)
print(obj1.dept1)
h=obj1.out()
print(h)
# print(DemoClass.dept1)
