#Multilevel Inheritance
class Father:
    def skills(self):
        print("i enjoy gardening.")
               
class Mother(Father):
    def skills(self):
        print('i love cooking.')
         
class Child(Mother):
    def skills(self):
        Father.skills(self)
        Mother.skills(self)
        print("I enjoy PUB-G")
         
c=Child()
c.skills()
# Father.skills(c)
# Mother.skills(c)

        
        