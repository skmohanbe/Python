class details:
    i=0
    def __init__(self,name,email,mobNumber):
        self.name=name
        self.email=email
        self.mobNumber=mobNumber
        
    def __repr__(self): #__str__
        return f"{self.name} {self.email} {self.mobNumber}"
        
obj1=details("Raj","Raj@gmail.com",89373482394)
print(obj1)
obj2=details("Mohan","Moh@gmail.com",3674628347)
print(obj2)
