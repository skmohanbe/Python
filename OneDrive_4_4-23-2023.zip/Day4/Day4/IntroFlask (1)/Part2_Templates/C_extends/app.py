from flask import Flask,render_template
app=Flask(__name__)

@app.route('/')
def home():
    posts = [{
    'author': 'Nishant',
        'title': 'Blog Post 1',
        'content': 'First post content',
        'date_posted': 'July 26, 2022'
    },
    {'author': 'Dr Wu',
        'title': 'Blog Post 2',
        'content': 'Second post content',
        'date_posted': 'July 27, 2022' }
]
    return render_template('home.html',posts=posts,title='Home')

@app.route('/about')
def about():
    return render_template('about.html',title='About')
# create a next route for about page and render the  template about.html at /about
if __name__ == '__main__':
    app.run(host='127.0.0.1',debug=True,port=5000)
