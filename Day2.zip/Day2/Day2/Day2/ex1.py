# b=[1,1.2,'Test',(90,18),1,1,1,1,1,1,1]
# print(b)
# a=set()
a={1,1.2,"Nishant",(12,"Hello",(1,))}
print(a)
print(len(a),id(a),type(a))
# for i in a:
#     print(i)

#a.add(56)
a.discard("Nishant1")
#a.remove('Nishant1')

print(a)
print(len(a),id(a),type(a))
