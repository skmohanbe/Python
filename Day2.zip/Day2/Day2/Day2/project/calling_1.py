import os,sys
sys.path.append(os.path.join(os.getcwd(),'bin'))

from module1 import Area,t,odd_even
choice,area=Area()
print(f'The area of {choice} is {area}')
#   
# t.sleep(4)
# # 
# # # 
# a = input("Enter a number: ")
# a = int(a)
# num,out,fact1 = odd_even(a)
#                   
# print(f'The value {num} is {out} and factorial is {fact1}.') 