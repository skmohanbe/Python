def democall(name):
    print(f'<<<<{name}>>>>')
    
    
if __name__=="__main__":
    democall('Test')