import file2
print("This is file3 and namespace is :- ",__name__)