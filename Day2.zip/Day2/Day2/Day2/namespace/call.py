def out(name):
    print(f"<{name}>")
    
    
if __name__ =="__main__":    
    out("Raj")