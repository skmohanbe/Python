from call import *
import file1
import file2
out('Manish')
print(__name__)