# import file1
print("This is file2 and namespace is :- ",__name__)