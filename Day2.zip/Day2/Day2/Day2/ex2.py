def call():
    print("this is call function.")
    out='56'
    another="56"
    new=90
    return new,out #{"var":new,"out":out}#[new,out]

h=call()
print(h)
