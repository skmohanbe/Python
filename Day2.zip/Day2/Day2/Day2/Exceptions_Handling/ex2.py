def main():
    try :
        for line in readfile('lines.txt'):
            print(line.strip())
            
    except IOError as e:
        print("File Not Found Error:-",e)
        
    except ValueError as v:
        print('Bad Ext.',v)
        
    except NameError as n:
        print('Name of file is incorrect',n)
   
   
def readfile(filename): 
    if filename.endswith('.txt'):
        fh=open(filename)
        return fh
    else:
        raise ValueError('EXT. Should Be .txt')
    
main()