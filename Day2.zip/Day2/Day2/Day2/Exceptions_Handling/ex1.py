try :
    fh=open('lines.txt')
    for line in fh:
        print(line.strip())
    a=1/0# ZeroDivisionError
except IOError as o:
    print("Input/Output Error:-",o)
    fh1 =open('dummy.txt')
    for line in fh1:
        print(line.strip())
        
except ZeroDivisionError as  z:
    print('1/0 Error:-',z)    
    
    
except Exception as e  :
    print("Error Solved!",e)
 
else: 
    print("If Try block fails to throw an exception the else execute")
     
 
finally:
    print("This is finally Block.")   
    try:
        fh.close() #Handle the Exception ?
    except Exception as e:
        print('',e)
        
    
print("###############")
import random
print(random.random())