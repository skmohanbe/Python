def details(firstname,surname='meena',age=89):
    name1=firstname+' '+surname 
    return name1,age 


h=details("Raj")
print(h)
 
m=details('Manish','Sharma',age=90)
print(m)