import time as t
def Area():
    import math
    print('''Shapes:
        1.Triangle
        2.Rectangle
        3.Circle
        4.Square''')
    list1=['Triangle','Rectangle','Circle','Square']
    option = eval(input('Enter you choice: '))
    choice='None'
    if type(option)==type(67):
        if option<=len(list1) :
            choice=list1[option-1]
    elif type(option)==type(67.90):
        pass
    elif option.lower() in [n.lower() for n in list1]:
        choice =option
       
    if option == 1 or choice.lower()=='triangle' :
        a,b,c = eval(input('Enter 3 sides of triangle: '))
        s = (a+b+c)/2
        area=math.sqrt(s*(s-a)*(s-b)*(s-c))
        #print('The area of triangle is',area)
    elif option == 2 or choice.lower()=='rectangle':
        a,b = eval(input('Enter 2 sides of rectangle: '))
        area =a*b
        #print('The area of rectangle is',area)
    elif option == 3 or choice.lower()=='circle':
        r = eval(input('Enter radius of circle: '))
        area =  math.pi * r**2
        #print('The area of circle is',area)
    elif option == 4 or choice.lower()=='square':
        a = eval(input('Enter side of square: '))
        area = a*a
        #print('The area of square is',area)
    else:
        print('Invalid option!!!')
        choice=None
        area=None
        
    return choice,area

def odd_even(number=5):
    import math     
    if (number % 2) == 1:
        str1 = "Odd"
        fact = math.factorial(number)
    else:
        str1 = "Even"
        fact = math.factorial(number)  
    return number, str1, fact  



if __name__ =="__main__":       
    print('=================================================================')
    choice,area=Area()
    print(f'The area of {choice} is {area}')
    # # print('==================================')
    t.sleep(4)
    # 
    # # 
    a = input("Enter a number: ")
    a = int(a)
    num,out,fact1 = odd_even(a)
                    
    print(f'The value {num} is {out} and factorial is {fact1}.') 
    print('===================================================================')
else :
    print("I am running with anyother python file")        
     
    

