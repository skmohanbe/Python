out="Test" #global
def details(firstname,surname='meena',age=89):
    global name1,out
    out="new" #local
    name1=firstname+' '+surname #local
    return name1,age,out 


h=details("Raj")
print(h)
print(out)