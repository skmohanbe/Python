def details(firstname,surname,age,*marks,**subjects): #*args > tuple ,**kwargs> dict
    name1=firstname+' '+surname 
    return name1,age,marks,subjects


h=details("Raj",'Meena',89,90,56,89,45,78,math=89,hindi=45,science=78)
print(h)
 
