def call():
    
    yield 5
    print("hello")
    yield 1
    print("Hii")
    yield 5
    print("No")




h=call()
print(next(h))
print(next(h))
print(next(h))
