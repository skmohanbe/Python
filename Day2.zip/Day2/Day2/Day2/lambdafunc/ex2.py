# seq=[23,45,68,89,88,78,67]
# f=list(filter(lambda x : x%2!=0 , seq))
# print(f)

input_1="IN3456DI1213@123DE48776LH786768I"
print(input_1)
f=''.join(list(filter(lambda x : x not in [str(i) for i in range(10)],input_1)))
print(f)
