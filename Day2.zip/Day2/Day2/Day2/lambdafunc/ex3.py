#list comprehension in python
# out=[]
# for i in range(1,10001):
#     out.append(i)
# print(out)
#[loop_var for loop_var in iterObject]
# f=[i for i in range(1,1001)]
# print(f)
# #[loop_var for loop_var in iterObject if exp]
# f=[i for i in range(1,1001) if i%2==1]
# print(f)
# #[loop_var for loop_var in iterObject if exp1 if exp2]
# f=[i for i in range(1,30) if i%2==1 if i%5==0]
# print(f)
# #[loop_var if exp else value for loop_var in iterObject ]
# f=[i if i%2==1 else "Out" for i in range(1,1001) ]
# print(f)
#['0','1'-----'9']
out='0' not in [str(i) for i in range(10)]
print(out)


