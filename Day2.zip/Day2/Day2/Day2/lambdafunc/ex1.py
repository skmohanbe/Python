a=lambda x=3,y=2 : x**2+y**2+2*x/0.23+2*y/0.25+x/y
print(a)
print(type(a))
b=a(3,2)
print(b)
b=a(y=2,x=3)
print(b)
b=a()
print(b)