buffersize=150#5000byts
fh=open('lines.txt','rb')
out=open('out.txt','wb')
buffer=fh.read(buffersize)
while buffer:
    out.write(buffer)
    buffer=fh.read(buffersize)
    print(".")
    
print("done")

fh.close()
out.close()