fh=open('lines.txt','r')
out=open('out.txt','a')

for line in fh:
    if line.strip().startswith('01') or line.strip().startswith('04') :
        print(line.strip(),file=out)
    print(".")
    
print("Done")