a='   this is nisHaNt hOuse.       '
print(a,len(a))
a=a.strip()#a.rstrip()#a.lstrip()
print(a,len(a))
b=a.replace('is', 'mm',2)#a.swapcase()#a.lower()#a.upper()#a.capitalize()
print(b)