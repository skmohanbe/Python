#fh=open(filename,mode)# r>read , w>write  r+>read/write , a>append
# fh=open('lines.txt')
# print(fh)
# for out in fh :
#     print(out.strip())
# 
# fh.seek(0)
# f=fh.readlines()#fh.readline()
# print(f)

# fh.close()
# del fh
# print(fh)
# 
# g=fh.readline()
with open('lines.txt','r') as fh:
    for line in fh :
        print(line.strip())

fh.readline()